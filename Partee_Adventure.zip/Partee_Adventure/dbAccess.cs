﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace Partee_Adventure
{
    public class dbAccess
    {
        public static string getConnection()
        {
            return ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
        }
	}
}